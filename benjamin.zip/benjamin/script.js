// canvas is always a square
const CANVAS_SIZE = 300;

let image;
let input;
let output;

window.onload = () => {
    input = document.getElementById("input");
    output = document.getElementById("output");

    input.width = CANVAS_SIZE;
    input.height = CANVAS_SIZE;
    output.width = CANVAS_SIZE;
    output.height = CANVAS_SIZE;

    document.addEventListener("dragover", (e) => {
        e.preventDefault();
    });

    document.addEventListener("drop", e => {
        e.preventDefault();

        const reader = new FileReader();
        reader.readAsDataURL(e.dataTransfer.files[0]);
        reader.onload = () => {
            const image = new Image();
            image.src = reader.result;
            image.onload = () => {
                const context = input.getContext("2d");

                let x;
                let y;
                let width;
                let height;
                if(image.width > image.height) {
                    width = CANVAS_SIZE;
                    height = CANVAS_SIZE * image.height / image.width;
                    x = 0;
                    y = (CANVAS_SIZE - height) / 2;
                }else{
                    width = CANVAS_SIZE * image.width / image.height;
                    height = CANVAS_SIZE;
                    x = (CANVAS_SIZE - width) / 2;
                    y = 0
                }
                context.clearRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);
                context.drawImage(image, x, y, width, height);
            }
        }
    })
}

function convert() {
    let inputContext = input.getContext("2d");
    let outputContext = output.getContext("2d");

    let imageData = inputContext.getImageData(0, 0, CANVAS_SIZE, CANVAS_SIZE);

    for (let i = 0; i < imageData.data.length; i++) {
        let byte = imageData.data[i];
        
        // play with image data :D


        imageData.data[i] = byte;
    }

    outputContext.putImageData(imageData, 0, 0);
}
